---

name: 💬 Questions / Help
about: If you have questions, please check our IRC or Slack
---

## 💬 Questions and Help

### Please note that this issue tracker is not a help form and this issue will be closed.

For questions or help please see:

- [StackOverflow - Zalenium](https://stackoverflow.com/questions/tagged/zalenium)
- [Slack channel - #zalenium channel](https://seleniumhq.herokuapp.com/)
