
Zalenium is 100% [open source](https://github.com/zalando/zalenium){:target="_blank"}
&mdash;
Issue [tracker](https://github.com/zalando/zalenium/issues){:target="_blank"}
&mdash;
[License](https://github.com/zalando/zalenium/blob/master/LICENSE.md){:target="_blank"}
&mdash;
[Security](https://github.com/zalando/zalenium/blob/master/SECURITY.md){:target="_blank"}
&mdash;
[Performance](https://github.com/zalando/zalenium/blob/master/docs/performance.md){:target="_blank"}

