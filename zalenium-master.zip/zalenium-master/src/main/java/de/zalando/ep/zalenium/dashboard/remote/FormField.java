package de.zalando.ep.zalenium.dashboard.remote;

public class FormField {
    public String keyName;
}
